#!/bin/bash

# Function to start the http-server and Serveo
start_servers() {
  # Start the http-server in the background
  http-server -c-1 &
  HTTP_SERVER_PID=$!

  # Wait for the http-server to start
  sleep 5

  # Start Serveo to expose the server
  ssh -R 80:localhost:8080 serveo.net
}

# Trap to handle interrupt and kill background processes
trap "kill $HTTP_SERVER_PID; exit" INT

# Infinite loop to keep the servers running
while true; do
  start_servers
  sleep 1
done

