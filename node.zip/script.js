async function getGPTResponse(prompt) {
    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer 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`
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo',
                messages: [{role: 'user', content: prompt}],
                max_tokens: 150
            })
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        return data.choices[0].message.content.trim();
    } catch (error) {
        console.error('Error fetching GPT response:', error);
        return '죄송합니다, 응답을 가져올 수 없습니다.';
    }
}

async function startConversation(userInput) {
    const userPrompt = userInput;
    const gptResponse = await getGPTResponse(userPrompt);
    const responseBox = document.getElementById('response');
    responseBox.innerHTML += `<p><strong>사용자:</strong> ${userInput}</p>`;
    responseBox.innerHTML += `<p><strong>새싹이:</strong> ${gptResponse}</p>`;
    speak(gptResponse);
}

function speak(text) {
    const speech = new SpeechSynthesisUtterance(text);
    speech.lang = 'ko-KR';
    window.speechSynthesis.speak(speech);
}

function startRecognition() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'ko-KR';
    recognition.start();

    recognition.onresult = async function(event) {
        const userSpeech = event.results[0][0].transcript;
        document.getElementById('response').innerHTML += `<p><strong>사용자 (음성):</strong> ${userSpeech}</p>`;
        await startConversation(userSpeech);
    };

    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
    };

    recognition.onend = function() {
        console.log('Speech recognition ended.');
    };
}

document.getElementById('invoke-button').addEventListener('click', async () => {
    // Handle text input
    const userInput = document.getElementById('textInput').value;
    if (userInput.trim() !== '') {
        document.getElementById('response').innerHTML += `<p><strong>사용자 (텍스트):</strong> ${userInput}</p>`;
        await startConversation(userInput);
        document.getElementById('textInput').value = '';
    }

    // Handle voice input
    startRecognition();
});

